export const MODULES = ["Test Case Generator", "LLM Response Judge", "GENAI Compass"];
