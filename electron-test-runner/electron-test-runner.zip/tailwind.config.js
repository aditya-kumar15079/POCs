module.exports = {
  content: ["./renderer/**/*.{js,jsx,html}"],
  theme: {
    extend: {},
  },
  plugins: [],
};
