# Electron BAT Runner

This Electron app demonstrates how to run a `.bat` file when a button is clicked in the UI.

## Setup

```bash
npm install
npm start

